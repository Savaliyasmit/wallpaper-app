//
//  MenuVC.swift
//  TodoApp
//
//  Created by smit on 10/12/24.
//

import UIKit

class MenuVC: UIViewController {

    @IBOutlet weak var tblView: UITableView!
    var sideItemNames:[String] = ["favourtie","settings"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTblView()
    }
    
    private func setupTblView(){
        tblView.register(.init(nibName: "MenuItemCell", bundle: nil),  forCellReuseIdentifier: "MenuItemCell")
        tblView.register(.init(nibName: "customeHeaderSideMenuCell", bundle: nil),  forCellReuseIdentifier: "customeHeaderSideMenuCell")
        tblView.delegate = self
        tblView.dataSource = self
        tblView.isScrollEnabled = false
        
    }
}

extension MenuVC:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sideItemNames.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MenuItemCell") as? MenuItemCell else {
            return .init()
        }
        cell.lblName.text = sideItemNames[indexPath.row]
        cell.layer.borderColor = UIColor.black.cgColor
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "customeHeaderSideMenuCell") as? customeHeaderSideMenuCell else {
            return .init()
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 100
    }
  

}
