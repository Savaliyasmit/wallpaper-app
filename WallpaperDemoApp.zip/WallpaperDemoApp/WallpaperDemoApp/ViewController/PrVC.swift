//
//  PrVC.swift
//  TodoApp
//
//  Created by smit on 25/10/24.
//

import UIKit
import SideMenu

class PrVC: UIViewController {
    
    @IBOutlet weak var clvView: UICollectionView!
    @IBOutlet weak var clvImgView: UICollectionView!
    
    var menu: SideMenuNavigationController?
    var arrayOfCatgory:[String] = ["Anime","Ai","ashatic"]
    
    private let refresh = UIRefreshControl()
    
    let categories: [Category] = [
        Category(name: "Anime", imageName: ["SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1"]),
        Category(name: "Ai", imageName: ["SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1", "SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1"]),
        Category(name: "Ashatic", imageName: ["SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1", "SpalshScreen_1", "back"]),
        Category(name: "blue", imageName: ["SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1"]),
        Category(name: "Dark", imageName: ["SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1", "SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1"]),
        Category(name: "Popular", imageName: ["SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1", "SpalshScreen_1", "back"]),
        Category(name: "Romantic", imageName: ["SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1"]),
        Category(name: "Country", imageName: ["SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1", "SpalshScreen_1", "back", "SpalshScreen_1"]),
        Category(name: "Games", imageName: ["SpalshScreen_1", "back", "empty_Img", "SpalshScreen_1", "SpalshScreen_1", "back"])
    ]
    
    var imagesByCategory:[String:[String]] = [
        "Anime":["SpalshScreen_1","SpalshScreen_1","SpalshScreen_1","SpalshScreen_1","SpalshScreen_1","SpalshScreen_1","SpalshScreen_1","back","empty_Img","SpalshScreen_1"],
        "Ai":["SpalshScreen_1","back","empty_Img","SpalshScreen_1","SpalshScreen_1","back","empty_Img","SpalshScreen_1"],
        "ashatic":["SpalshScreen_1","back","empty_Img","SpalshScreen_1","SpalshScreen_1","back"]
    ]
    
    var selectedCatgory:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupClv()
        setDefaultCategory()
        setupRefreshCtr()
        setupSwipeGestures()
        setUpSideMenu()
        print("categories---->",categories,"selectedCatgory",selectedCatgory)
    }
    
private func setUpSideMenu(){
        if  let menuVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MenuVC") as? MenuVC {
        menu = SideMenuNavigationController(rootViewController: menuVc)
            menu?.blurEffectStyle = .systemMaterialDark
            menu?.isNavigationBarHidden = true
            menu?.leftSide = true
            menu?.alwaysAnimate = true
            menu?.presentationStyle = .menuSlideIn
//            menu?.statusBarEndAlpha = 0 // Make status bar transparent
        }
    }
    
    @IBAction func openSideMenu(_ sender: UIButton){
        if let menu = menu {
            present(menu , animated: true, completion: nil)
        }
    }
    private func setupSwipeGestures() {
            // Left swipe gesture to move to previous category
            let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
            leftSwipe.direction = .left
            self.view.addGestureRecognizer(leftSwipe)
        
            // Right swipe gesture to move to next category
            let rightSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
            rightSwipe.direction = .right
            self.view.addGestureRecognizer(rightSwipe)
        }
    
    @objc private func handleSwipe(_ gesture: UISwipeGestureRecognizer) {
        if gesture.direction == .left {
            // Swipe left: Go to next category
         let nextIndex = (selectedCatgory + 1) % categories.count
            print("nextIndex---> ",nextIndex)
            if selectedCatgory < categories.count - 1 {
                clvView.scrollToItem(at:IndexPath(row: nextIndex, section: 0) , at: .centeredHorizontally, animated: true)
                updateCategorySelection(to: nextIndex)
          }
    
        }else if gesture.direction == .right {
            // Swipe right: Go to previous category
           let previousIndex = (selectedCatgory - 1 + categories.count) % categories.count
            print("previousIndex---> ",previousIndex)
            if previousIndex < categories.count - 1 {
                clvView.scrollToItem(at:IndexPath(row: previousIndex, section: 0) , at: .centeredHorizontally, animated: true)
                updateCategorySelection(to: previousIndex)}
        }
    }
    
    private func updateCategorySelection(to index: Int) {
        let previousIndex = selectedCatgory
        selectedCatgory = index
        // Update UI for the category
        updateCategoryUI(previousIndex: previousIndex)
    }
    
    private func updateCategoryUI(previousIndex: Int) {
           clvView.reloadItems(at: [IndexPath(row: previousIndex, section: 0)])
           clvView.reloadItems(at: [IndexPath(row: selectedCatgory, section: 0)])
           clvImgView.reloadData()
       }
    
    private func setupRefreshCtr(){
        clvImgView.refreshControl = refresh
            //        tblView.addSubview(refresh)
            //        refresh.translatesAutoresizingMaskIntoConstraints = false
            //        NSLayoutConstraint.activate([
            //            refresh.centerXAnchor.constraint(equalTo: tblView.centerXAnchor),
            //            refresh.centerYAnchor.constraint(equalTo: tblView.centerYAnchor)
            //        ])
            refresh.addTarget(self, action: #selector(refreshItemsData(_:)), for: .valueChanged)
            refresh.tintColor = UIColor.white
        
    }
    
@objc private func refreshItemsData(_ sender:UIRefreshControl){
    DispatchQueue.main.asyncAfter(deadline: .now() + 2){ [weak self] in
            guard let self = self else {
                return
            }
            self.clvImgView.reloadData()
            sender.endRefreshing()
        }
    }
    
func setupClv(){
        clvView.tag = 1
    clvView.register(.init(nibName: "PrClvCell", bundle: nil), forCellWithReuseIdentifier: "PrClvCell")
        clvView.delegate = self
        clvView.dataSource = self
        clvView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        
        clvImgView.tag = 2
    clvImgView.register(.init(nibName: "clVImgCell", bundle: nil), forCellWithReuseIdentifier: "clVImgCell")
        clvImgView.delegate = self
        clvImgView.dataSource = self
        clvImgView.contentInset = UIEdgeInsets(top: 2, left: 5, bottom: 5, right: 5)
    }
    
    private func setDefaultCategory() {
            selectedCatgory = 0
            clvView.reloadItems(at: [IndexPath(row: selectedCatgory, section: 0)])   // Refresh category
            clvImgView.reloadData()
         }

}



extension PrVC: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch collectionView.tag {
        case 1:
            return  categories.count
        case 2:
            return   categories[selectedCatgory].imageName?.count ?? 0
        default:
            return 0
        }
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch collectionView.tag {
        case 1:
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PrClvCell", for: indexPath) as? PrClvCell else { return .init() }
            
    
            cell.selectView.isHidden = indexPath.item != selectedCatgory
          cell.lblCatrgory.textColor = indexPath.item == selectedCatgory ? .systemBlue : .white
            cell.lblCatrgory.text = "\(categories[indexPath.item].name)"
            
            return cell
        case 2:
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "clVImgCell", for: indexPath) as? clVImgCell else { return .init() }
            cell.layer.cornerRadius = 6
            cell.layer.borderWidth = 2
            
            if let imageName = categories[selectedCatgory].imageName?[indexPath.item] {
                cell.ImgWall.image = UIImage(named: imageName)
            }
            return cell
        default:
            return .init()
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch collectionView.tag {
        case 1:
            let itemWidth = Int(collectionView.bounds.width  - 80 ) / 3
            
            print(Int(itemWidth))
            return CGSize(width: Int(itemWidth), height:Int(clvView.bounds.height))
            
            
        case 2:  let itemWidth = (collectionView.bounds.width - 18) / 3
            print(Int(itemWidth))
            return CGSize(width: Int(itemWidth), height:Int(250))
        default:
            return CGSize()
        }
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        switch collectionView.tag {
        case 1: return  0
        case 2: return  4
        default : return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        switch collectionView.tag {
        case 1: return  10
        case 2: return  2
        default : return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch collectionView.tag {
        case 1:
            let previousIndex = selectedCatgory
            if selectedCatgory != indexPath.item {
                selectedCatgory = indexPath.item
                updateCategoryUI(previousIndex: previousIndex)
            }
            print("1--->",selectedCatgory)
        case 2:
            if let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "WallpaperVC") as? WallpaperVC ,let imageName = categories[selectedCatgory].imageName?[indexPath.row]   {
                vc.reciveWallpaperName = imageName
               self.navigationController?.pushViewController(vc, animated: true)
                }
        default:
            break
        }
    }
}

