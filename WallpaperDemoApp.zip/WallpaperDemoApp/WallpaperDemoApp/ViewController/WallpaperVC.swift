//
//  WallpaperVCViewController.swift
//  TodoApp
//
//  Created by smit on 09/12/24.
//

import UIKit
import Photos

class WallpaperVC: UIViewController {

    @IBOutlet weak var wallImageName: UIImageView!
    
    @IBOutlet weak var onBtnSave: UIButton!
    
    var reciveWallpaperName:String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewOfImage()
        onBtnSave.layer.cornerRadius = 25
        onBtnSave.layer.borderWidth  = 2
        onBtnSave.layer.borderColor = UIColor.black.cgColor
    }
   
    func saveImageToGallery(image: UIImage) {
        // Check authorization status
        PHPhotoLibrary.requestAuthorization { status in
            switch status {
            case .authorized:
                // Save the image to the photo library
                UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                print("Image saved successfully!")
            case .denied, .restricted:
                print("Access to photo library denied or restricted.")
            case .notDetermined:
                print("Authorization status not determined.")
            case .limited:
                print("limited acees")
            @unknown default:
                print("Unknown authorization status.")
            }
        }
    }

    @IBAction func onBtnSaveToGallery(_ sender: UIButton) {
        if let imgName = reciveWallpaperName {
            saveImageToGallery(image: UIImage(named: imgName) ?? .init() )
                               
}
    }
    
    @IBAction func onBtnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    private func viewOfImage(){
        if let imgName = reciveWallpaperName {
            wallImageName.image = UIImage(named: "\(imgName)")
        }
    }
}
