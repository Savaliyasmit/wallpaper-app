//
//  File.swift
//  TodoApp
//
//  Created by smit on 02/12/24.
//


struct Category{
    let name:String
    let imageName:[String]?
}
