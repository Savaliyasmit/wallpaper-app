//
//  PrClvCell.swift
//  TodoApp
//
//  Created by smit on 28/10/24.
//

import UIKit

class PrClvCell: UICollectionViewCell {

    @IBOutlet weak var lblCatrgory: UILabel!
 
    @IBOutlet weak var selectView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectView.isHidden = true
        selectView.layer.cornerRadius = 5
    }

}
