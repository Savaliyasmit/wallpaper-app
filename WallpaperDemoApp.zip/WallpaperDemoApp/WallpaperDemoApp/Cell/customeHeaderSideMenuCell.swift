//
//  customeHeaderSideMenuCell.swift
//  TodoApp
//
//  Created by smit on 10/12/24.
//

import UIKit

class customeHeaderSideMenuCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
}
