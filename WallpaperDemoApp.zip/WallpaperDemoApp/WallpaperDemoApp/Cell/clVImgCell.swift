//
//  clVImgCell.swift
//  TodoApp
//
//  Created by smit on 28/10/24.
//

import UIKit

class clVImgCell: UICollectionViewCell {

    @IBOutlet weak var ImgWall: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
