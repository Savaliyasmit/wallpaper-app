//
//  MenuItemCell.swift
//  TodoApp
//
//  Created by smit on 10/12/24.
//

import UIKit

class MenuItemCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

  
    
}
